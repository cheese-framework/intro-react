export const API_URL = "http://api.coinlayer.com/live";
export const API_KEY = "";
