import "./components/style.css";

function Custom() {
  return (
    <div className="container">
      <div className="text">0</div>
      <div className="actions">
        <button className="action">Start</button>
        <button className="reset">Reset</button>
      </div>
    </div>
  );
}

export default Custom;
