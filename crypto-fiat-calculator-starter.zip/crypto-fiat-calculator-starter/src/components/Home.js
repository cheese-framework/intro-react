import Layout from "./Layout";

const Home = () => {
  return (
    <Layout title="Crypto Converter">
      <div className="container">
        <div className="row my-5">
          <div className="col-lg-6 mx-auto">
            <div className="card">
              <div className="card-body p-3">
                <form>
                  <div className="form-group">
                    <label htmlFor="btc">BTC:</label>
                    <input
                      type="number"
                      placeholder="1"
                      id="btc"
                      className="form-control"
                    />
                  </div>
                  <div className="form-group mt-4">
                    <label htmlFor="usd">USD:</label>
                    <input
                      type="number"
                      placeholder="10000"
                      id="usd"
                      className="form-control"
                      readOnly
                    />
                  </div>
                  <div className="form-group mt-4">
                    <input
                      className="btn btn-success"
                      type="submit"
                      value="Calculate"
                    />
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Home;
