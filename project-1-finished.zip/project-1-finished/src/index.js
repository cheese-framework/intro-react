import React from "react";
import ReactDOM from "react-dom";
import Custom from "./Custom";

// component, where to
ReactDOM.render(<Custom />, document.getElementById("root"));
